var myArray = [1, 2, 3, 4, 5];
var index = 10; // Accessing an index that doesn't exist
console.log(myArray[index]); // This will cause an index error
