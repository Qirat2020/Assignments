interface Person {
    name: string;
    status: string; // living or deceased
  }
  
  const guestList: Person[] = [
    { name: "Leonardo da Vinci", status: "deceased" },
    { name: "Jane Austen", status: "deceased" },
    { name: "Elon Musk", status: "living" },
  ];
  
  function generateInvitation(person: Person): string {
    if (person.status === "living") {
      return `Dear ${person.name}, you are invited to dinner. Looking forward to your presence!`;
    } else {
      return `Dear spirit of ${person.name}, you are invited to an otherworldly dinner. Your legacy lives on!`;
    }
  }
  
  guestList.forEach((person) => {
    const invitation = generateInvitation(person);
    console.log(invitation);
  });