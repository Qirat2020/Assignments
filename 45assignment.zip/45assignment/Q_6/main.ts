let whitespaceName ="\n\t syeda qirat \t\n" ;

console.log(whitespaceName);

let withoutwhitespaceName = whitespaceName.trim();

console.log(withoutwhitespaceName);