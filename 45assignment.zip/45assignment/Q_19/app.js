var guestlist = ["hamza", "aqsa", "qirat", "ali"];
//guestlist. forEach(oneGuest => console.log(`salam ${oneGuest}, would you like to dinner with us`));
var lengthGuests = guestlist.length;
console.log("we are inviting total ".concat(lengthGuests, " guests."));
