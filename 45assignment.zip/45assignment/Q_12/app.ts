let friendsName =["qirat","aqsa","hania","elsa",];

friendsName.forEach(friendName => console.log(`hello ${friendName}, how are you`));