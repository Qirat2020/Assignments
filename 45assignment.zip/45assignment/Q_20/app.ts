// Define an array of countries
const countries: string[] = ["USA", "Canada", "Australia", "Germany", "Japan"];

// Log the array to the console
console.log(countries);