// Define an array of countries
var countries = ["USA", "Canada", "Australia", "Germany", "Japan"];
// Log the array to the console
console.log(countries);
