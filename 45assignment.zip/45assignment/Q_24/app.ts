//const string1: string = "Apple";
//const string2: string = "Orange";

//console.log(string1 ===string2); 
//console.log(string1 !==string2);

//text using the lower case function;

//const mixedCasestring: string = "hello world";

//console.log(mixedCasestring.toLowerCase() === "hello world");

//numerical test involving equality and enequality, greaterthan and lessthan,greaterthan or equal to, lessthan and equal to,

//const num1:number = 10;
//const num2:number = 5;

//console.log(num1 === num2);
//console.log(num1 !== num2);
//console.log(num1 > num2);
//console.log(num1 <num2);
//console.log(num1 >= num2);
//console.log(num1 <= num2);

//test usning "and" and "or" operators

//const condition1: boolean = true;
//const condition2:boolean = false;
//console.log(condition1 && condition2);
//console.log(condition1 || condition2);

//test whether an item is in a array;

const fruits: string[]=["apple","mango","orange","banana"];
console.log(fruits.includes("apple"));
console.log(fruits.includes("apple"))

