// Function to make magicians great
function makeGreat(magicians) {
    magicians.forEach(function (magician) {
        magician.name = "the Great ".concat(magician.name);
    });
}
// Function to show magicians
function showMagicians(magicians) {
    magicians.forEach(function (magician) {
        console.log(magician.name);
    });
}
// Sample data
var magicians = [
    { name: "Harry Houdini" },
    { name: "David Copperfield" },
    { name: "Penn Jillette" },
    { name: "Teller" }
];
// Call makeGreat to modify magicians
makeGreat(magicians);
// Call showMagicians to display modified list
showMagicians(magicians);
