// Define the Magician interface
interface Magician {
    name: string;
}

// Function to make magicians great
function makeGreat(magicians: Magician[]): void {
    magicians.forEach(magician => {
        magician.name = `the Great ${magician.name}`;
    });
}

// Function to show magicians
function showMagicians(magicians: Magician[]): void {
    magicians.forEach(magician => {
        console.log(magician.name);
    });
}

// Sample data
const magicians: Magician[] = [
    { name: "Harry Houdini" },
    { name: "David Copperfield" },
    { name: "Penn Jillette" },
    { name: "Teller" }
];

// Call makeGreat to modify magicians
makeGreat(magicians);

// Call showMagicians to display modified list
showMagicians(magicians);