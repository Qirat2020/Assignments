let emploee: string[] = ["ahsan","hamza","aqsa","qirat"];

for(let i=0; 1<=emploee.length; i++){
if(emploee[i] == "admin"){
    console.log("hello admin, would you like to see a status report?")
}
else{
    console.log(`hello ${emploee[i]}`)
}
}