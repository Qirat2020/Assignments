var emploee = ["ahsan", "hamza", "aqsa"];
for (var i = 1; 1 <= emploee.length; i++) {
    console.log(i);
}
