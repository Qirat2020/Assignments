var alienColor = "green";
if (alienColor === "green") {
    console.log("You earned 5 points.");
}
else if (alienColor === "yellow") {
    console.log("You earned 10 points.");
}
else if (alienColor === "red") {
    console.log("You earned 15 points.");
}
var aliinColor = "yellow";
if (alienColor === "green") {
    console.log("You earned 5 points.");
}
else if (alienColor === "yellow") {
    console.log("You earned 10 points.");
}
else if (alienColor === "red") {
    console.log("You earned 15 points.");
}
var aleenColor = "red";
if (alienColor === "green") {
    console.log("You earned 5 points.");
}
else if (alienColor === "yellow") {
    console.log("You earned 10 points.");
}
else if (alienColor === "red") {
    console.log("You earned 15 points.");
}
