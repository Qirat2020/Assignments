var current_users = ["user1", "user2", "user3", "user4", "user5"];
var new_users = ["user3", "user6", "user7", "user8", "user9"];
for (var _i = 0, new_users_1 = new_users; _i < new_users_1.length; _i++) {
    var new_user = new_users_1[_i];
    if (current_users.includes(new_user)) {
        console.log("The username ".concat(new_user, " is not available. Please enter a new username."));
    }
    else {
        console.log("The username ".concat(new_user, " is available."));
    }
}
