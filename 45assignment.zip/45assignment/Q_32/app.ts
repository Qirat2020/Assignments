let current_users: string[] = ["user1", "user2", "user3", "user4", "user5"];
let new_users: string[] = ["user3", "user6", "user7", "user8", "user9"];

for (let new_user of new_users) {
    if (current_users.includes(new_user)) {
        console.log(`The username ${new_user} is not available. Please enter a new username.`);
    } else {
        console.log(`The username ${new_user} is available.`);
    }
}   