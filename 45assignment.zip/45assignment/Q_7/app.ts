let a: number = 10;

let b: number = 5;

console.log(a/b);
console.log(a+b);
console.log(a-b);
console.log(a*b);