var a = 10;
var b = 5;
console.log(a / b);
console.log(a + b);
console.log(a - b);
console.log(a * b);
