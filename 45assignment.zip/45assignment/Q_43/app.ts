function makeGreat(magicians: string[]): string[] {
    let greatMagicians: string[] = [];
    for (let magician of magicians) {
        greatMagicians.push(`Great ${magician}`);
    }
    return greatMagicians;
}

function showMagicians(magicians: string[]): void {
    for (let magician of magicians) {
        console.log(magician);
    }
}

let magicians: string[] = ["Harry", "Hermione", "Ron"];
let greatMagicians: string[] = makeGreat([...magicians]); // Creating a copy of the original array
showMagicians(magicians); // Output the original array
showMagicians(greatMagicians); // Output the array with "Great" added to each magician's name