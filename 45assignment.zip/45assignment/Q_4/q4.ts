let name1: string = ("Hazrat Ali said");

console.log(`${name1} "Each person's Grief is according to his courage" `);