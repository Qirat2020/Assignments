// Define the original guest list
let guestList: string[] = ["Guest1", "Guest2", "Guest3"];

// Print original invitations
guestList.forEach(guest => {
    console.log(`Dear ${guest}, You are invited to the dinner.`);
});

// Identify the guest who can't make it
const guestUnavailable = "Guest2";
console.log(`Unfortunately, ${guestUnavailable} can't make it to the dinner.`);

// Replace the unavailable guest with a new one
const newGuest = "NewGuest";
const indexOfUnavailableGuest = guestList.indexOf(guestUnavailable);
if (indexOfUnavailableGuest !== -1) {
    guestList[indexOfUnavailableGuest] = newGuest;
}

// Print updated invitations
guestList.forEach(guest => {
    console.log(`Dear ${guest}, You are invited to the dinner.`)
});