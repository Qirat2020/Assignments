function make_shirt(size: string, message: string): void {
    console.log(`The shirt is ${size} size and it says: "${message}"`);
}

// Example call
make_shirt("Large", "Hello, World!");