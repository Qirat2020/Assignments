function make_shirt(size, message) {
    console.log("The shirt is ".concat(size, " size and it says: \"").concat(message, "\""));
}
// Example call
make_shirt("Large", "Hello, World!");
