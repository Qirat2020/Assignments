var friendsName = ["qirat", "aqsa", "sakeena", "hania"];
friendsName.forEach(function (friendname) { return console.log(friendname); });
