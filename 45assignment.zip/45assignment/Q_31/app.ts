let users: string[] = ["John", "Jane", "Alice"];

if (users.length === 0) {
    console.log("We need to find some users!");
} else {
    users = []; // Remove all usernames
    console.log("All users have been removed.");
}