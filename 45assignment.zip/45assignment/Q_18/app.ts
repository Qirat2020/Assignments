// Define an array of places
let places: string[] = ["Tokyo", "Paris", "New York", "Sydney", "Rio de Janeiro"];

// Print original order
console.log("Original Order:", places);

// Print in alphabetical order without modifying the actual list
console.log("Alphabetical Order:", [...places].sort());

// Verify original order is still intact
console.log("Original Order (unchanged):", places);

// Print in reverse alphabetical order without modifying the actual list
console.log("Reverse Alphabetical Order:", [...places].sort().reverse());

// Verify original order is still intact
console.log("Original Order (unchanged):", places);

// Reverse the order of the list
places.reverse();
console.log("Reversed Order:", places);

// Reverse the order again to get back to the original order
places.reverse();
console.log("Original Order:", places);

// Sort the array in alphabetical order
places.sort();
console.log("Sorted Alphabetical Order:", places);

// Sort the array in reverse alphabetical order
places.sort((a, b) => b.localeCompare(a));
console.log("Sorted Reverse Alphabetical Order:", places);