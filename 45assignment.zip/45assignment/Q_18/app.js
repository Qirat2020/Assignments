var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
// Define an array of places
var places = ["Tokyo", "Paris", "New York", "Sydney", "Rio de Janeiro"];
// Print original order
console.log("Original Order:", places);
// Print in alphabetical order without modifying the actual list
console.log("Alphabetical Order:", __spreadArray([], places, true).sort());
// Verify original order is still intact
console.log("Original Order (unchanged):", places);
// Print in reverse alphabetical order without modifying the actual list
console.log("Reverse Alphabetical Order:", __spreadArray([], places, true).sort().reverse());
// Verify original order is still intact
console.log("Original Order (unchanged):", places);
// Reverse the order of the list
places.reverse();
console.log("Reversed Order:", places);
// Reverse the order again to get back to the original order
places.reverse();
console.log("Original Order:", places);
// Sort the array in alphabetical order
places.sort();
console.log("Sorted Alphabetical Order:", places);
// Sort the array in reverse alphabetical order
places.sort(function (a, b) { return b.localeCompare(a); });
console.log("Sorted Reverse Alphabetical Order:", places);
