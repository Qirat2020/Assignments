let alienColor: string = "green";

if (alienColor === "green") {
    console.log("You just earned 5 points for shooting the alien.");
} else {
    console.log("You just earned 10 points.");
}
let alieenColor: string = "red";

if (alienColor === "green") {
    console.log("You just earned 5 points for shooting the alien.");
} else {
    console.log("You just earned 10 points.");
}