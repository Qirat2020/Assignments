const favoritePizzas: string[] = ["Pepperoni", "Margherita", "BBQ Chicken"];

for (const pizza of favoritePizzas) {
    console.log(`I like ${pizza} pizza.`);
}

console.log("I really love pizza!");