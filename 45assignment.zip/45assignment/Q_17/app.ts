let dinnerGuests: string[] = ["Alice", "Bob", "Charlie", "David", "Eve"];

console.log("Due to a delay, the new dinner table won't arrive in time, and I can only invite two people.");

while (dinnerGuests.length > 2) {
    const removedGuest = dinnerGuests.pop();
    console.log(`Sorry, ${removedGuest}, I can't invite you to dinner.`);
}

for (const remainingGuest of dinnerGuests) {
    console.log(`You're still invited, ${remainingGuest}!`);
}

// Remove the last two names
dinnerGuests.pop();
dinnerGuests.pop();

console.log(`Updated Guest List: ${dinnerGuests}`);