function make_shirt(size, message) {
    if (size === void 0) { size = "large"; }
    if (message === void 0) { message = "I love TypeScript"; }
    return { size: size, message: message };
}
// Creating a large shirt with the default message
var largeShirtDefaultMessage = make_shirt();
console.log(largeShirtDefaultMessage);
// Creating a medium shirt with the default message
var mediumShirtDefaultMessage = make_shirt("medium");
console.log(mediumShirtDefaultMessage);
// Creating a shirt of any size with a different message
var smallShirtCustomMessage = make_shirt("small", "TypeScript is awesome!");
console.log(smallShirtCustomMessage);
