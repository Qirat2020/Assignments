var string1 = "Apple";
var string2 = "Orange";
console.log(string1 === string2);
//console.log(string1 !==string2);
