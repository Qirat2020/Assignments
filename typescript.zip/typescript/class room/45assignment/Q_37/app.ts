interface Shirt {
    size: string;
    message: string;
  }
  
  function make_shirt(size: string = "large", message: string = "I love TypeScript"): Shirt {
    return { size, message };
  }
  
  // Creating a large shirt with the default message
  const largeShirtDefaultMessage = make_shirt();
  console.log(largeShirtDefaultMessage);
  
  // Creating a medium shirt with the default message
  const mediumShirtDefaultMessage = make_shirt("medium");
  console.log(mediumShirtDefaultMessage);
  
  // Creating a shirt of any size with a different message
  const smallShirtCustomMessage = make_shirt("small", "TypeScript is awesome!");
  console.log(smallShirtCustomMessage);