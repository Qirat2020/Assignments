var friendsName = ["qirat", "aqsa", "hania", "elsa",];
friendsName.forEach(function (friendName) { return console.log("hello ".concat(friendName, ", how are you")); });
