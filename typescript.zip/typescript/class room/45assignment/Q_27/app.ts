let alienColor: string = "green";

if (alienColor === "green") {
    console.log("You earned 5 points.");
} else if (alienColor === "yellow") {
    console.log("You earned 10 points.");
} else if (alienColor === "red") {
    console.log("You earned 15 points.");
}
let aliinColor: string = "yellow";

if (alienColor === "green") {
    console.log("You earned 5 points.");
} else if (alienColor === "yellow") {
    console.log("You earned 10 points.");
} else if (alienColor === "red") {
    console.log("You earned 15 points.");
}
let aleenColor: string = "red";

if (alienColor === "green") {
    console.log("You earned 5 points.");
} else if (alienColor === "yellow") {
    console.log("You earned 10 points.");
} else if (alienColor === "red") {
    console.log("You earned 15 points.");
}