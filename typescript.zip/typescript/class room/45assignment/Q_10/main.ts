//addition
console.log(4+4);

//subtraction
console.log(12-4);

//multiplicatin
console.log(4*2);

//division
console.log(16/2);