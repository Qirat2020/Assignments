let friendsName = ["qirat","aqsa","sakeena","hania"];

friendsName.forEach(friendname => console.log(friendname));