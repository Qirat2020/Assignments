let message: string = "Eric";

console.log(`hello ${message}, "would you like to learn some python today"`);