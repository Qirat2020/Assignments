var message = "Eric";
console.log("hello ".concat(message, ", \"would you like to learn some python today\""));
