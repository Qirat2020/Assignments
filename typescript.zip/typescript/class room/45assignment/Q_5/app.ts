let famous_person: string = "Hazrat Ali";

let message: string = "accept the appology' even if it is not sincer";

console.log(`${famous_person} once said, ${message}`);