var famous_person = "Hazrat Ali";
var message = "accept the appology' even if it is not sincer";
console.log("".concat(famous_person, " once said, ").concat(message));
