// Create objects containing items
var items = {
    laptop: {
        name: "Laptop",
        description: "A portable computer for work and entertainment.",
        price: 999.99,
    },
    book: {
        name: "Book",
        description: "A printed or digital publication containing literary or informational content.",
        price: 19.99,
    },
    smartphone: {
        name: "Smartphone",
        description: "A mobile device that combines communication and computing capabilities.",
        price: 799.99,
    },
    headphones: {
        name: "Headphones",
        description: "An audio accessory worn over the ears for listening to sound from a device.",
        price: 149.99,
    },
};
// Access and print information about items
console.log(items.laptop);
console.log(items.book);
console.log(items.smartphone);
console.log(items.headphones);
