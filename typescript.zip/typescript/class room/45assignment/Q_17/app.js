var dinnerGuests = ["Alice", "Bob", "Charlie", "David", "Eve"];
console.log("Due to a delay, the new dinner table won't arrive in time, and I can only invite two people.");
while (dinnerGuests.length > 2) {
    var removedGuest = dinnerGuests.pop();
    console.log("Sorry, ".concat(removedGuest, ", I can't invite you to dinner."));
}
for (var _i = 0, dinnerGuests_1 = dinnerGuests; _i < dinnerGuests_1.length; _i++) {
    var remainingGuest = dinnerGuests_1[_i];
    console.log("You're still invited, ".concat(remainingGuest, "!"));
}
// Remove the last two names
dinnerGuests.pop();
dinnerGuests.pop();
console.log("Updated Guest List: ".concat(dinnerGuests));
