var guestList = [
    { name: "Leonardo da Vinci", status: "deceased" },
    { name: "Jane Austen", status: "deceased" },
    { name: "Elon Musk", status: "living" },
];
function generateInvitation(person) {
    if (person.status === "living") {
        return "Dear ".concat(person.name, ", you are invited to dinner. Looking forward to your presence!");
    }
    else {
        return "Dear spirit of ".concat(person.name, ", you are invited to an otherworldly dinner. Your legacy lives on!");
    }
}
guestList.forEach(function (person) {
    var invitation = generateInvitation(person);
    console.log(invitation);
});
