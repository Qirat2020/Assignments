var favoriteTransportation = ["Honda motorcycle", "Tesla car", "Yamaha scooter"];
favoriteTransportation.forEach(function (item) {
    console.log("I would like to own a ${item}.");
});
