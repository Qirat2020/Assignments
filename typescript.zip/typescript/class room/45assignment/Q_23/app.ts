let car = 'subaru';

// Test 1: Is car == 'subaru'? I predict True.
console.log(car == 'subaru');

// Test 2: Is car == 'ford'? I predict False.
console.log(car == 'ford');

// Test 3: Is car === 'subaru'? I predict True.
console.log(car === 'subaru');

// Test 4: Is car === 'Subaru'? I predict False (case sensitive).
console.log(car === 'Subaru');

// Test 5: Is car != 'toyota'? I predict True.
console.log(car != 'toyota');

// Test 6: Is car !== 'subaru'? I predict False.
console.log(car !== 'subaru');

// Test 7: Is car !== 'ford'? I predict True.
console.log(car !== 'ford');

// Test 8: Is car > 'ford'? I predict True ('s' comes after 'f' alphabetically).
console.log(car > 'ford');

// Test 9: Is car < 'toyota'? I predict True ('s' comes before 't' alphabetically).
console.log(car < 'toyota');

// Test 10: Is car.length == 6? I predict False (length of 'subaru' is 6).
console.log(car.length == 6);