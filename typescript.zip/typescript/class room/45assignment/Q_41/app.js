function show_magicians(magicians) {
    magicians.forEach(function (magician) { return console.log(magician); });
}
var magicianNames = ["Harry Houdini", "David Copperfield", "Penn Jillette", "Teller"];
show_magicians(magicianNames);
