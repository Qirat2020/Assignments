var name1 = ("Hazrat Ali said");
console.log("".concat(name1, " \"Each person's Grief is according to his courage\" "));
