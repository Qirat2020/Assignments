"use strict";
let firstName = "syeda qirat";
console.log(firstName.toLowerCase());
console.log(firstName.toUpperCase());
console.log(firstName.charAt(0).toUpperCase() + firstName.slice(1));
