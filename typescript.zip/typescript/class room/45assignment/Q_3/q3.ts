let firstName: string = "syeda qirat";

console.log(firstName.toLowerCase());

console.log(firstName.toUpperCase());

console.log(firstName.charAt(0).toUpperCase() + firstName.slice(1));