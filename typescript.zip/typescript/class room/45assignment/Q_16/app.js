var dinnerGuests = ["Alice", "Bob", "Charlie"];
// Informing about the bigger dinner table
console.log("Good news! We found a bigger dinner table!");
// Add a new guest to the beginning of the array
dinnerGuests.unshift("David");
// Add a new guest to the middle of the array
var middleIndex = Math.floor(dinnerGuests.length / 2);
dinnerGuests.splice(middleIndex, 0, "Eva");
// Use append() (push in TypeScript) to add a new guest to the end
dinnerGuests.push("Frank");
// Print invitation messages
for (var _i = 0, dinnerGuests_1 = dinnerGuests; _i < dinnerGuests_1.length; _i++) {
    var guest = dinnerGuests_1[_i];
    console.log("Dear ".concat(guest, ", you are invited to the dinner party!"));
}
