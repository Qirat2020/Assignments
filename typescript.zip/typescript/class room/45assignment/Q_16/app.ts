let dinnerGuests: string[] = ["Alice", "Bob", "Charlie"];

// Informing about the bigger dinner table
console.log("Good news! We found a bigger dinner table!");

// Add a new guest to the beginning of the array
dinnerGuests.unshift("David");

// Add a new guest to the middle of the array
const middleIndex = Math.floor(dinnerGuests.length / 2);
dinnerGuests.splice(middleIndex, 0, "Eva");

// Use append() (push in TypeScript) to add a new guest to the end
dinnerGuests.push("Frank");

// Print invitation messages
for (const guest of dinnerGuests) {
    console.log(`Dear ${guest}, you are invited to the dinner party!`);
}