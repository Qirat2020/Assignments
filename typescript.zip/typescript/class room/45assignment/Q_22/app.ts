let myArray: number[] = [1, 2, 3, 4, 5];
let index = 10; // Accessing an index that doesn't exist

console.log(myArray[index]); // This will cause an index error