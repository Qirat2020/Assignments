var fav = 10;
var message = "my fav number is";
console.log(message, fav);
