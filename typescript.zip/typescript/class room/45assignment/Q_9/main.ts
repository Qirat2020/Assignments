let fav: number = 10;

let message = "my fav number is";

console.log(message, fav);