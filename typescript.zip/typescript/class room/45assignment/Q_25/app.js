// Passing version
var alien_color = 'green';
if (alien_color === 'green') {
    console.log("Player just earned 5 points.");
}
// Failing version
var aleen_color = 'red';
if (alien_color === 'green') {
    console.log("Player just earned 5 points.");
}
