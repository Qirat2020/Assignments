// Passing version
let alien_color: string = 'green';

if (alien_color === 'green') {
    console.log("Player just earned 5 points.");
}
// Failing version
let aleen_color: string = 'red';

if (alien_color === 'green') {
    console.log("Player just earned 5 points.");
}